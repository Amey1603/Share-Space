package com.example.share_space

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
